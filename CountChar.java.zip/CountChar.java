import java.util.Scanner;
public class CountChar {

	public static void main(String[] args) {
		Scanner scnr=new Scanner(System.in);
		
		char cCompChar='n';
		
		int iStrCount=0, iCharCount=0,strSize=0;
		String str;
		
		System.out.println("���ڿ��� �Է��ϼ���");
		str=scnr.nextLine();
		
		strSize=str.length();
		while(iStrCount<strSize) 
			{
			if(str.charAt(iStrCount)==cCompChar)
				{
				
				iCharCount++;

				}
		iStrCount++;
			}
		

	System.out.println("����"+cCompChar+"��"+iCharCount+"�� �߻���");

	}
}
