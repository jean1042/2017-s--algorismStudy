public class loopTest3{
	public static void main(String[] args)
	{
		
		forTest();
		whileTest();
		dowhileTest();
		
	}

	public static void forTest()
		{
			int sum,i;
			System.out.println("for�� �̿�");
			for (sum=0,i=1;i<=100; i++){
			if (i%2==0) continue;
			sum+=i;
			}
	System.out.println(sum);

		}


	public static void whileTest() {
			int sum2, i2;
			System.out.println("while�� �̿�");
	sum2=0; i2=1;
				while(i2<=100){
						if (i2%2!=0) 
						
								sum2+=i2;
								i2++;
						}
						
					System.out.println(sum2);
					}
				
	
			
		
	
public static void dowhileTest(){
int sum3,i3;
System.out.println("do-while �� �̿�");
sum3=0;
i3=1;
do{
	if (i3%2!=0)
		sum3+=i3; i3++;
}
while(i3<=100);
System.out.println(sum3);
}
}
	
